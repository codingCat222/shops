import { Router } from 'express';
import { requireAuth } from '../../middleware/auth.middleware.js';
import {
  getOrCreateDirectChat,
  createGroup,
  createCommunity,
  getUserChats,
  getChatRoom,
  sendMessage,
  markMessagesAsRead,
  togglePinChat,
  clearChat,
  addParticipant,
  removeParticipant,
  blockUser,
  unblockUser,
  getBlockedUsers,
  createInvite,
  useInvite
} from './chat.controller.js';

const router = Router();

router.use(requireAuth);

router.get('/', getUserChats);
router.get('/blocked', getBlockedUsers);
router.get('/:chatRoomId', getChatRoom);

router.post('/direct/:userId', getOrCreateDirectChat);
router.post('/group', createGroup);
router.post('/community', createCommunity);
router.post('/:chatRoomId/messages', sendMessage);
router.post('/:chatRoomId/read', markMessagesAsRead);
router.post('/:chatRoomId/pin', togglePinChat);
router.post('/:chatRoomId/clear', clearChat);
router.post('/:chatRoomId/participants', addParticipant);
router.post('/:chatRoomId/invite', createInvite);
router.post('/invite/:code/use', useInvite);

router.delete('/:chatRoomId/participants/:userId', removeParticipant);

router.post('/block/:userId', blockUser);
router.delete('/block/:userId', unblockUser);

export default router;