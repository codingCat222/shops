import { prisma } from '../../config/db.js';
import { ChatRoomType, ParticipantRole } from '../../generated/prisma/enums.js';
import { ApiError } from '../../utils/ApiError.js';

const isUUID = (str: string) => {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);
};

export const getOrCreateDirectChat = async (userId: string, otherUserIdOrUsername: string) => {
  let otherUserId = otherUserIdOrUsername;
  
  if (!isUUID(otherUserIdOrUsername)) {
    const user = await prisma.user.findUnique({
      where: { username: otherUserIdOrUsername }
    });
    
    if (!user) {
      throw new ApiError(404, 'User not found');
    }
    otherUserId = user.id;
  }

  let chatRoom = await prisma.chatRoom.findFirst({
    where: {
      type: ChatRoomType.DIRECT,
      OR: [
        { initiatorId: userId, participantId: otherUserId },
        { initiatorId: otherUserId, participantId: userId }
      ]
    },
    include: {
      participants: {
        include: { user: true }
      },
      messages: {
        orderBy: { createdAt: 'desc' },
        take: 50,
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              username: true,
              role: true,
              avatarColor: true,
              profilePicture: true
            }
          }
        }
      }
    }
  });

  if (chatRoom) return chatRoom;

  chatRoom = await prisma.chatRoom.create({
    data: {
      type: ChatRoomType.DIRECT,
      creatorId: userId,
      initiatorId: userId,
      participantId: otherUserId,
      participants: {
        create: [
          { userId, role: ParticipantRole.MEMBER },
          { userId: otherUserId, role: ParticipantRole.MEMBER }
        ]
      }
    },
    include: {
      participants: {
        include: { user: true }
      },
      messages: {
        orderBy: { createdAt: 'desc' },
        take: 50,
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              username: true,
              role: true,
              avatarColor: true,
              profilePicture: true
            }
          }
        }
      }
    }
  });

  return chatRoom;
};

export const createGroup = async (userId: string, data: { name: string; description?: string; memberIds: string[] }) => {
  const chatRoom = await prisma.chatRoom.create({
    data: {
      type: ChatRoomType.GROUP,
      name: data.name,
      description: data.description,
      creatorId: userId,
      participants: {
        create: [
          { userId, role: ParticipantRole.ADMIN },
          ...data.memberIds.map((id: string) => ({
            userId: id,
            role: ParticipantRole.MEMBER
          }))
        ]
      },
      settings: {
        notification: true,
        approveMembers: true,
        addMembers: true
      }
    },
    include: {
      participants: {
        include: { user: true }
      }
    }
  });

  return chatRoom;
};

export const createCommunity = async (userId: string, data: {
  name: string;
  description?: string;
  settings?: Record<string, any>;
}) => {
  const chatRoom = await prisma.chatRoom.create({
    data: {
      type: ChatRoomType.COMMUNITY,
      name: data.name,
      description: data.description,
      creatorId: userId,
      participants: {
        create: [
          { userId, role: ParticipantRole.ADMIN }
        ]
      },
      settings: data.settings || {
        visibility: true,
        notification: true,
        approveMembers: true,
        protectTraders: true,
        addMembers: true
      }
    },
    include: {
      participants: {
        include: { user: true }
      }
    }
  });

  return chatRoom;
};

export const getUserChats = async (userId: string) => {
  const participantRooms = await prisma.chatRoomParticipant.findMany({
    where: { userId, leftAt: null },
    include: {
      chatRoom: {
        include: {
          participants: {
            include: { user: true }
          },
          messages: {
            orderBy: { createdAt: 'desc' },
            take: 1,
            include: {
              sender: {
                select: {
                  id: true,
                  name: true,
                  username: true,
                  role: true,
                  avatarColor: true,
                  profilePicture: true
                }
              }
            }
          }
        }
      }
    },
    orderBy: {
      chatRoom: {
        updatedAt: 'desc'
      }
    }
  });

  return participantRooms.map((p) => {
    const chatRoom = p.chatRoom;
    const messages = chatRoom.messages || [];
    return {
      ...chatRoom,
      isPinned: p.isPinned,
      unreadCount: messages.filter((m) => !m.isRead && m.senderId !== userId).length,
      lastMessage: messages[0]?.content || null,
      lastMessageTime: messages[0]?.createdAt || null
    };
  });
};

export const getChatRoom = async (chatRoomId: string, userId: string) => {
  const chatRoom = await prisma.chatRoom.findUnique({
    where: { id: chatRoomId },
    include: {
      participants: {
        include: { user: true }
      },
      messages: {
        orderBy: { createdAt: 'asc' },
        where: { isDeleted: false },
        include: {
          sender: {
            select: {
              id: true,
              name: true,
              username: true,
              role: true,
              avatarColor: true,
              profilePicture: true
            }
          }
        }
      }
    }
  });

  if (!chatRoom) {
    throw new ApiError(404, 'Chat room not found');
  }

  const isParticipant = chatRoom.participants.some((p) => p.userId === userId);
  if (!isParticipant) {
    throw new ApiError(403, 'You are not a participant of this chat');
  }

  return chatRoom;
};

export const sendMessage = async (chatRoomId: string, senderId: string, content: string, attachmentName?: string) => {
  const chatRoom = await prisma.chatRoom.findUnique({
    where: { id: chatRoomId }
  });

  if (!chatRoom) {
    throw new ApiError(404, 'Chat room not found');
  }

  const participant = await prisma.chatRoomParticipant.findUnique({
    where: {
      chatRoomId_userId: {
        chatRoomId,
        userId: senderId
      }
    }
  });

  if (!participant) {
    throw new ApiError(403, 'You are not a participant of this chat');
  }

  const message = await prisma.chatMessage.create({
    data: {
      chatRoomId,
      senderId,
      content,
      attachmentName
    },
    include: {
      sender: {
        select: {
          id: true,
          name: true,
          username: true,
          role: true,
          avatarColor: true,
          profilePicture: true
        }
      }
    }
  });

  await prisma.chatRoom.update({
    where: { id: chatRoomId },
    data: {
      lastMessage: content,
      lastMessageAt: new Date(),
      updatedAt: new Date()
    }
  });

  return message;
};

export const markMessagesAsRead = async (chatRoomId: string, userId: string) => {
  await prisma.chatMessage.updateMany({
    where: {
      chatRoomId,
      senderId: { not: userId },
      isRead: false
    },
    data: {
      isRead: true
    }
  });

  await prisma.chatRoomParticipant.updateMany({
    where: {
      chatRoomId,
      userId
    },
    data: {
      lastReadAt: new Date()
    }
  });
};

export const togglePinChat = async (chatRoomId: string, userId: string) => {
  const participant = await prisma.chatRoomParticipant.findUnique({
    where: {
      chatRoomId_userId: {
        chatRoomId,
        userId
      }
    }
  });

  if (!participant) {
    throw new ApiError(404, 'Participant not found');
  }

  return await prisma.chatRoomParticipant.update({
    where: {
      chatRoomId_userId: {
        chatRoomId,
        userId
      }
    },
    data: {
      isPinned: !participant.isPinned
    }
  });
};

export const clearChat = async (chatRoomId: string, userId: string) => {
  const participant = await prisma.chatRoomParticipant.findUnique({
    where: {
      chatRoomId_userId: {
        chatRoomId,
        userId
      }
    }
  });

  if (!participant) {
    throw new ApiError(403, 'You are not a participant of this chat');
  }

  return await prisma.chatMessage.updateMany({
    where: {
      chatRoomId
    },
    data: {
      isDeleted: true,
      deletedAt: new Date()
    }
  });
};

export const addParticipant = async (chatRoomId: string, userId: string, inviterId: string) => {
  const chatRoom = await prisma.chatRoom.findUnique({
    where: { id: chatRoomId },
    include: {
      participants: true
    }
  });

  if (!chatRoom) {
    throw new ApiError(404, 'Chat room not found');
  }

  if (chatRoom.type === ChatRoomType.DIRECT) {
    throw new ApiError(400, 'Cannot add participants to direct chat');
  }

  const existing = chatRoom.participants.find((p) => p.userId === userId);
  if (existing) {
    throw new ApiError(400, 'User is already a participant');
  }

  const inviterParticipant = chatRoom.participants.find((p) => p.userId === inviterId);
  const settings = chatRoom.settings as Record<string, any> | null;
  if (chatRoom.type === ChatRoomType.GROUP && settings?.approveMembers) {
    if (!inviterParticipant || inviterParticipant.role !== ParticipantRole.ADMIN) {
      throw new ApiError(403, 'Only admins can add new members');
    }
  }

  return await prisma.chatRoomParticipant.create({
    data: {
      chatRoomId,
      userId,
      role: ParticipantRole.MEMBER
    },
    include: {
      user: true
    }
  });
};

export const removeParticipant = async (chatRoomId: string, userId: string, removerId: string) => {
  const chatRoom = await prisma.chatRoom.findUnique({
    where: { id: chatRoomId },
    include: {
      participants: true
    }
  });

  if (!chatRoom) {
    throw new ApiError(404, 'Chat room not found');
  }

  if (chatRoom.type === ChatRoomType.DIRECT) {
    throw new ApiError(400, 'Cannot remove participants from direct chat');
  }

  const removerParticipant = chatRoom.participants.find((p) => p.userId === removerId);
  if (!removerParticipant || removerParticipant.role !== ParticipantRole.ADMIN) {
    throw new ApiError(403, 'Only admins can remove members');
  }

  return await prisma.chatRoomParticipant.update({
    where: {
      chatRoomId_userId: {
        chatRoomId,
        userId
      }
    },
    data: {
      leftAt: new Date()
    }
  });
};

export const blockUser = async (blockerId: string, blockedId: string, reason?: string) => {
  const existing = await prisma.block.findUnique({
    where: {
      blockerId_blockedId: {
        blockerId,
        blockedId
      }
    }
  });

  if (existing) {
    throw new ApiError(400, 'User already blocked');
  }

  return await prisma.block.create({
    data: {
      blockerId,
      blockedId,
      reason
    }
  });
};

export const unblockUser = async (blockerId: string, blockedId: string) => {
  return await prisma.block.delete({
    where: {
      blockerId_blockedId: {
        blockerId,
        blockedId
      }
    }
  });
};

export const getBlockedUsers = async (userId: string) => {
  return await prisma.block.findMany({
    where: { blockerId: userId },
    include: {
      blocked: true
    }
  });
};

export const createInvite = async (chatRoomId: string, createdById: string, maxUses: number = 1, expiresAt?: Date) => {
  const chatRoom = await prisma.chatRoom.findUnique({
    where: { id: chatRoomId }
  });

  if (!chatRoom) {
    throw new ApiError(404, 'Chat room not found');
  }

  const code = Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);

  return await prisma.chatInvite.create({
    data: {
      code,
      chatRoomId,
      createdById,
      maxUses,
      expiresAt
    }
  });
};

export const useInvite = async (code: string, userId: string) => {
  const invite = await prisma.chatInvite.findUnique({
    where: { code },
    include: {
      chatRoom: true
    }
  });

  if (!invite) {
    throw new ApiError(404, 'Invalid invite code');
  }

  if (!invite.isActive) {
    throw new ApiError(400, 'Invite link is inactive');
  }

  if (invite.expiresAt && invite.expiresAt < new Date()) {
    throw new ApiError(400, 'Invite link has expired');
  }

  if (invite.usedCount >= invite.maxUses) {
    throw new ApiError(400, 'Invite link has reached maximum uses');
  }

  const existing = await prisma.chatRoomParticipant.findUnique({
    where: {
      chatRoomId_userId: {
        chatRoomId: invite.chatRoomId,
        userId
      }
    }
  });

  if (existing) {
    throw new ApiError(400, 'You are already a participant');
  }

  await prisma.$transaction([
    prisma.chatInvite.update({
      where: { id: invite.id },
      data: { usedCount: { increment: 1 } }
    }),
    prisma.chatRoomParticipant.create({
      data: {
        chatRoomId: invite.chatRoomId,
        userId,
        role: ParticipantRole.MEMBER
      }
    })
  ]);

  return invite.chatRoom;
};