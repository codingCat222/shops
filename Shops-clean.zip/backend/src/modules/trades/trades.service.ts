import crypto from 'crypto';
import { prisma } from '../../config/db';
import { Prisma } from '../../generated/prisma/client.js';
import { ApiError } from '../../utils/ApiError';
import type { CreateTradeInput, ListTradesQuery } from './trades.validation';

const generatePickupCode = () => crypto.randomInt(100000, 999999).toString();

export const createTrade = async (creatorId: string, input: CreateTradeInput) => {
  return prisma.trade.create({
    data: {
      title: input.title,
      creatorId,
      amount: input.amount,
      type: input.type,
      category: input.category,
      condition: input.condition,
      specs: input.specs as Prisma.InputJsonValue | undefined,
      accountNumber: input.accountNumber,
      deliveryFee: input.deliveryFee,
      deliveryTime: input.deliveryTime,
      takeOffLocation: input.takeOffLocation,
      deliveryLocation: input.deliveryLocation,
      image: input.image,
      description: input.description,
      status: 'PENDING'
    }
  });
};

export const listTrades = async (userId: string | null, query: ListTradesQuery) => {
  const { page, limit, status, mine } = query;

  const where: Record<string, unknown> = {
    ...(status ? { status } : {})
  };

  if (mine) {
    if (!userId) {
      throw new ApiError(401, 'Not authenticated');
    }
    where.OR = [{ creatorId: userId }, { buyerId: userId }];
  }

  const [items, total] = await Promise.all([
    prisma.trade.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: 'desc' },
      include: {
        creator: { select: { id: true, username: true, name: true, avatarColor: true } },
        buyer: { select: { id: true, username: true, name: true, avatarColor: true } }
      }
    }),
    prisma.trade.count({ where })
  ]);

  return {
    items,
    pagination: { page, limit, total, totalPages: Math.ceil(total / limit) }
  };
};

export const getTradeById = async (id: string) => {
  const trade = await prisma.trade.findUnique({
    where: { id },
    include: {
      creator: { select: { id: true, username: true, name: true, avatarColor: true } },
      buyer: { select: { id: true, username: true, name: true, avatarColor: true } }
    }
  });

  if (!trade) {
    throw new ApiError(404, 'Trade not found');
  }

  return trade;
};

// Buyer funds escrow: locks them in as buyer, generates a pickup code, moves
// status to FUNDED. A trade can only be funded once, and never by its own
// creator (no self-dealing).
export const fundTrade = async (tradeId: string, buyerId: string) => {
  const trade = await prisma.trade.findUnique({ where: { id: tradeId } });

  if (!trade) {
    throw new ApiError(404, 'Trade not found');
  }
  if (trade.creatorId === buyerId) {
    throw new ApiError(400, 'You cannot fund your own trade listing');
  }
  if (trade.buyerId) {
    throw new ApiError(409, 'This trade has already been funded by another buyer');
  }
  if (trade.status !== 'PENDING' && trade.status !== 'DRAFT') {
    throw new ApiError(409, `Trade cannot be funded while in status ${trade.status}`);
  }

  const pickupCode = generatePickupCode();

  return prisma.trade.update({
    where: { id: tradeId },
    data: {
      buyerId,
      status: 'FUNDED',
      pickupCode,
      pickupAttempts: 0
    }
  });
};

// Seller verifies the buyer's pickup code on delivery. Limits attempts to
// prevent brute-forcing a 6-digit code (1,000,000 possibilities, but repeated
// guessing must still be bounded).
const MAX_PICKUP_ATTEMPTS = 5;

export const verifyPickupCode = async (tradeId: string, sellerId: string, code: string) => {
  const trade = await prisma.trade.findUnique({ where: { id: tradeId } });

  if (!trade) {
    throw new ApiError(404, 'Trade not found');
  }
  if (trade.creatorId !== sellerId) {
    throw new ApiError(403, 'Only the trade creator can verify pickup');
  }
  if (trade.status !== 'FUNDED') {
    throw new ApiError(409, 'Trade is not awaiting pickup verification');
  }
  if (trade.pickupAttempts >= MAX_PICKUP_ATTEMPTS) {
    throw new ApiError(429, 'Maximum pickup verification attempts exceeded');
  }

  if (trade.pickupCode !== code) {
    await prisma.trade.update({
      where: { id: tradeId },
      data: { pickupAttempts: { increment: 1 } }
    });
    throw new ApiError(400, 'Incorrect pickup code');
  }

  return prisma.trade.update({
    where: { id: tradeId },
    data: { status: 'DELIVERED' }
  });
};


const ALLOWED_TRANSITIONS: Record<string, string[]> = {
  DRAFT: ['PENDING'],
  PENDING: ['FUNDED', 'DISPUTED'],
  FUNDED: ['DELIVERED', 'DISPUTED'],
  DELIVERED: ['COMPLETED', 'DISPUTED'],
  COMPLETED: [],
  DISPUTED: [],
  REFUNDED: []
};

export const updateTradeStatus = async (
  tradeId: string,
  userId: string,
  userRole: string,
  nextStatus: string
) => {
  const trade = await prisma.trade.findUnique({ where: { id: tradeId } });

  if (!trade) {
    throw new ApiError(404, 'Trade not found');
  }

  const isParticipant = trade.creatorId === userId || trade.buyerId === userId;
  if (!isParticipant && userRole !== 'admin') {
    throw new ApiError(403, 'You are not a participant in this trade');
  }

  if (userRole !== 'admin') {
    const allowed = ALLOWED_TRANSITIONS[trade.status] ?? [];
    if (!allowed.includes(nextStatus)) {
      throw new ApiError(400, `Cannot transition trade from ${trade.status} to ${nextStatus}`);
    }
  }

  return prisma.trade.update({
    where: { id: tradeId },
    data: { status: nextStatus as never }
  });
};

export const forceCancelTrade = async (tradeId: string) => {
  const trade = await prisma.trade.findUnique({ where: { id: tradeId } });
  if (!trade) {
    throw new ApiError(404, 'Trade not found');
  }

  return prisma.trade.update({
    where: { id: tradeId },
    data: { status: 'REFUNDED' }
  });
};