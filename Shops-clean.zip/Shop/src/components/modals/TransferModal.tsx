import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

interface TransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTransfer: (amount: number, beneficiaryAccount: string, beneficiaryBank: string) => { ok: boolean; message: string };
  onAddAuditLog: (action: string, details: string, actor?: string) => void;
  activeUsername: string;
}

export default function TransferModal({ isOpen, onClose, onTransfer, onAddAuditLog, activeUsername }: TransferModalProps) {
  const [transferAmount, setTransferAmount] = useState('');
  const [transferBeneficiary, setTransferBeneficiary] = useState('');
  const [transferBank, setTransferBank] = useState('Guaranty Trust Bank (GTB)');
  const [error, setError] = useState<string | null>(null);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-3xl p-6 max-w-sm w-full border border-slate-100 shadow-2xl relative space-y-4"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center">
              <h3 className="text-lg font-display font-bold text-slate-900">Direct Wallet Transfer</h3>
              <p className="text-xs font-sans text-slate-500 mt-1">Disburse funds instantly to external Nigerian bank checking accounts.</p>
            </div>

            {error && (
              <div className="p-3 bg-red-50 text-red-700 rounded-xl border border-red-100 text-xs font-sans font-semibold">
                {error}
              </div>
            )}

            <div className="space-y-3 font-sans text-xs">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Beneficiary NUBAN account</label>
                <input
                  type="text"
                  maxLength={10}
                  value={transferBeneficiary}
                  onChange={(e) => setTransferBeneficiary(e.target.value)}
                  placeholder="e.g. 0123456789"
                  className="w-full text-sm px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Beneficiary Bank</label>
                <select
                  value={transferBank}
                  onChange={(e) => setTransferBank(e.target.value)}
                  className="w-full text-sm px-3 py-2 border border-slate-200 rounded-xl"
                >
                  <option value="Access Bank">Access Bank</option>
                  <option value="Zenith Bank">Zenith Bank</option>
                  <option value="Guaranty Trust Bank (GTB)">Guaranty Trust Bank (GTB)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Disbursement Amount (₦)</label>
                <input
                  type="number"
                  value={transferAmount}
                  onChange={(e) => setTransferAmount(e.target.value)}
                  placeholder="e.g. 2000"
                  className="w-full text-sm px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>
            </div>

            <button
              onClick={() => {
                const amt = parseFloat(transferAmount);
                setError(null);

                const result = onTransfer(amt, transferBeneficiary, transferBank);
                if (!result.ok) {
                  setError(result.message);
                  return;
                }

                onAddAuditLog('WALLET_TRANSFER', result.message, activeUsername);
                alert(`Transfer successfully dispatched! ${result.message}`);
                setTransferAmount('');
                setTransferBeneficiary('');
                onClose();
              }}
              className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-sans font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
            >
              Authorize Disbursal
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}