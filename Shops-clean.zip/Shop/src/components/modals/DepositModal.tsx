import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X } from 'lucide-react';

interface DepositModalProps {
  isOpen: boolean;
  onClose: () => void;
  onDeposit: (amount: number) => void;
  onAddAuditLog: (action: string, details: string, actor?: string) => void;
  activeUsername: string;
}

export default function DepositModal({ isOpen, onClose, onDeposit, onAddAuditLog, activeUsername }: DepositModalProps) {
  const [depositAmount, setDepositAmount] = useState('');

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <motion.div
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            className="bg-white rounded-3xl p-6 max-w-sm w-full border border-slate-100 shadow-2xl relative space-y-4"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center">
              <h3 className="text-lg font-display font-bold text-slate-900">Fund Naira Wallet</h3>
              <p className="text-xs font-sans text-slate-500 mt-1">Send funds directly to your virtual Wema Bank assignment vault.</p>
            </div>

            <div className="space-y-3 font-sans text-xs">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Enter Deposit amount (₦)</label>
                <input
                  type="number"
                  value={depositAmount}
                  onChange={(e) => setDepositAmount(e.target.value)}
                  placeholder="e.g. 50000"
                  className="w-full text-sm font-sans px-3 py-2 border border-slate-200 rounded-xl"
                />
              </div>

              <div className="p-3 bg-purple-50 rounded-xl border border-purple-100 flex justify-between text-slate-700">
                <div>
                  <span className="block text-[8px] text-slate-400 font-bold uppercase">Account number</span>
                  <strong className="font-mono text-sm text-slate-800">9482740294</strong>
                </div>
                <div>
                  <span className="block text-[8px] text-slate-400 font-bold uppercase">Assigned bank</span>
                  <strong className="text-purple-700 text-xs">WEMA Bank</strong>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                const amt = parseFloat(depositAmount);
                if (!amt || amt <= 0) return;

                onDeposit(amt);
                onAddAuditLog('WALLET_DEPOSIT', `Cleared credit transfer of ₦${amt.toLocaleString()} via virtual bank channel.`, activeUsername);
                alert(`Naira transfer verified! ₦${amt.toLocaleString()} added to your wallet balance.`);
                setDepositAmount('');
                onClose();
              }}
              className="w-full py-2.5 bg-green-600 hover:bg-green-700 text-white font-sans font-bold text-xs rounded-xl shadow-md transition-all cursor-pointer"
            >
              Verify Deposit Clearance
            </button>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}