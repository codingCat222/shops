import React, { createContext, useContext, useState, useEffect } from 'react';
import { ChatRoom, ChatMessage } from '../types/chat';
import { useAuth } from './AuthContext';
import { chatService, ChatRoom as ApiChatRoom } from '../services/chatService';
import { chatSocket } from '../sockets/chat.socket';

interface ChatContextType {
  chatRooms: ChatRoom[];
  sendMessage: (roomId: string, text: string) => void;
  getChatRoom: (roomId: string) => ChatRoom | undefined;
  getChatWithUser: (username: string) => ChatRoom | undefined;
  createChatRoom: (participantUsername: string, participantName: string) => void;
  markAsRead: (roomId: string) => void;
  totalUnread: number;
  startChatWithSeller: (sellerUsername: string, sellerName: string) => void;
  totalUnreadChats: number;
  loading: boolean;
  refreshChats: () => Promise<void>;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

const mapApiRoomToChatRoom = (apiRoom: any, currentUsername: string): ChatRoom => {
  let participants = apiRoom.participants || [];
  
  if (participants.length === 0) {
    const initiator = apiRoom.initiator;
    const participant = apiRoom.participant;
    
    if (initiator && initiator.username !== currentUsername) {
      participants = [{ user: initiator }];
    } else if (participant && participant.username !== currentUsername) {
      participants = [{ user: participant }];
    }
  }
  
  const otherParticipant = participants.find((p: any) => p.user?.username !== currentUsername);
  const isAI = apiRoom.type === 'DIRECT' && otherParticipant?.user?.username === 'micha_ai';
  
  let participantRole = 'user';
  if (isAI) {
    participantRole = 'ai';
  } else if (otherParticipant?.user?.role) {
    participantRole = otherParticipant.user.role;
  } else if (otherParticipant?.role) {
    participantRole = otherParticipant.role;
  }
  
  const unreadCount = apiRoom.messages?.filter((m: any) => !m.isRead && m.senderId !== currentUsername).length || 0;

  return {
    id: apiRoom.id,
    participantUsername: otherParticipant?.user?.username || otherParticipant?.username || 'Unknown',
    participantName: otherParticipant?.user?.name || otherParticipant?.name || 'Unknown',
    participantAvatar: (otherParticipant?.user?.name || otherParticipant?.name || '?').charAt(0).toUpperCase(),
    participantRole: participantRole as 'user' | 'seller' | 'ai',
    lastMessage: apiRoom.lastMessage || 'No messages',
    lastMessageTime: apiRoom.lastMessageAt ? new Date(apiRoom.lastMessageAt).toLocaleTimeString() : 'now',
    unreadCount: unreadCount,
    messages: apiRoom.messages?.map((m: any) => ({
      id: m.id,
      chatId: m.chatRoomId,
      senderUsername: m.sender?.username || 'Unknown',
      senderName: m.sender?.name || 'Unknown',
      senderRole: m.sender?.role as 'user' | 'seller' | 'ai' || 'user',
      content: m.content,
      timestamp: m.createdAt
    })) || [],
    isPinned: participants.find((p: any) => p.user?.username === currentUsername || p.username === currentUsername)?.isPinned || false,
    isAI: isAI,
    type: apiRoom.type,
    name: apiRoom.name,
    description: apiRoom.description,
    participants: participants
  };
};

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [chatRooms, setChatRooms] = useState<ChatRoom[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);

  const loadChats = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const response = await chatService.getUserChats();
      const mappedRooms = response.data.chats.map((room: any) => 
        mapApiRoomToChatRoom(room, user.username)
      );
      setChatRooms(mappedRooms);
    } catch (error) {
      console.error('Failed to load chats:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadChats();
  }, [user]);

  useEffect(() => {
    if (!user) return;

    chatSocket.on('onNewMessage', (message: any) => {
      setChatRooms(prev => {
        const existing = prev.find(r => r.id === message.chatRoomId);
        if (!existing) {
          loadChats();
          return prev;
        }

        const newMsg: ChatMessage = {
          id: message.id,
          chatId: message.chatRoomId,
          senderUsername: message.sender.username,
          senderName: message.sender.name,
          senderRole: message.sender.role as 'user' | 'seller' | 'ai',
          content: message.content,
          timestamp: message.createdAt
        };

        return prev.map(room => {
          if (room.id === message.chatRoomId) {
            const isMine = message.senderId === user.id;
            const shouldMarkRead = !isMine && selectedRoomId === message.chatRoomId;
            
            return {
              ...room,
              lastMessage: message.content,
              lastMessageTime: 'now',
              messages: [...room.messages, newMsg],
              unreadCount: shouldMarkRead ? 0 : (isMine ? room.unreadCount : room.unreadCount + 1)
            };
          }
          return room;
        });
      });
    });

    chatSocket.on('onMessagesRead', (data: any) => {
      setChatRooms(prev => 
        prev.map(room => {
          if (room.id === data.chatRoomId) {
            return { ...room, unreadCount: 0 };
          }
          return room;
        })
      );
    });

    return () => {
      chatSocket.off('onNewMessage', () => {});
      chatSocket.off('onMessagesRead', () => {});
    };
  }, [user, selectedRoomId]);

  const sendMessage = async (roomId: string, text: string) => {
    if (!user) return;

    try {
      await chatService.sendMessage(roomId, { content: text });
      
      setChatRooms(prev =>
        prev.map((room) => {
          if (room.id === roomId) {
            const newMsg: ChatMessage = {
              id: `temp_${Date.now()}`,
              chatId: roomId,
              senderUsername: user.username,
              senderName: user.name,
              senderRole: user.role === 'seller' ? 'seller' : 'user',
              content: text,
              timestamp: new Date().toISOString()
            };
            return {
              ...room,
              lastMessage: text,
              lastMessageTime: 'now',
              messages: [...room.messages, newMsg]
            };
          }
          return room;
        })
      );

      chatSocket.sendMessage(roomId, text);
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const getChatRoom = (roomId: string) => {
    return chatRooms.find((room) => room.id === roomId);
  };

  const getChatWithUser = (username: string) => {
    return chatRooms.find((room) => room.participantUsername === username);
  };

  const createChatRoom = async (participantUsername: string, participantName: string) => {
    if (!user) return;

    const existing = chatRooms.find((c) => c.participantUsername === participantUsername);
    if (existing) return;

    try {
      const response = await chatService.getOrCreateDirectChat(participantUsername);
      const newRoom = mapApiRoomToChatRoom(response.data.chatRoom, user.username);
      setChatRooms([newRoom, ...chatRooms]);
    } catch (error) {
      console.error('Failed to create chat room:', error);
    }
  };

  const markAsRead = (roomId: string) => {
    if (!user) return;
    
    setChatRooms((prev) =>
      prev.map((room) => {
        if (room.id === roomId) {
          return { ...room, unreadCount: 0 };
        }
        return room;
      })
    );

    setSelectedRoomId(roomId);
    chatService.markAsRead(roomId);
    chatSocket.markAsRead(roomId);
  };

  const refreshChats = loadChats;

  const totalUnread = chatRooms.reduce((sum, r) => sum + r.unreadCount, 0);

  return (
    <ChatContext.Provider value={{
      chatRooms,
      sendMessage,
      getChatRoom,
      getChatWithUser,
      createChatRoom,
      markAsRead,
      totalUnread,
      startChatWithSeller: createChatRoom,
      totalUnreadChats: totalUnread,
      loading,
      refreshChats
    }}>
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
}