import React, { createContext, useContext, useState } from 'react';
import { useAuth } from './AuthContext';

interface WalletContextType {
  depositOpen: boolean;
  transferOpen: boolean;
  openDeposit: () => void;
  closeDeposit: () => void;
  openTransfer: () => void;
  closeTransfer: () => void;
  deposit: (amount: number) => void;
  transfer: (amount: number, beneficiaryAccount: string, beneficiaryBank: string) => { ok: boolean; message: string };
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

// NOTE: backend `payments` module (Paystack/Kuda) is an empty stub and the
// keys in .env are placeholders. deposit()/transfer() only mutate the local
// user object via AuthContext.updateUser — no real money moves and nothing
// is persisted server-side. Replace both with real API calls once the
// payments module and provider keys are live.
export function WalletProvider({ children }: { children: React.ReactNode }) {
  const { user, updateUser } = useAuth();
  const [depositOpen, setDepositOpen] = useState(false);
  const [transferOpen, setTransferOpen] = useState(false);

  const openDeposit = () => setDepositOpen(true);
  const closeDeposit = () => setDepositOpen(false);
  const openTransfer = () => setTransferOpen(true);
  const closeTransfer = () => setTransferOpen(false);

  const deposit = (amount: number) => {
    if (!user || !amount || amount <= 0) return;
    updateUser({ ...user, walletBalance: user.walletBalance + amount });
  };

  const transfer = (amount: number, beneficiaryAccount: string, beneficiaryBank: string) => {
    if (!user) return { ok: false, message: 'Not signed in' };
    if (!amount || amount <= 0) return { ok: false, message: 'Enter a valid amount' };
    if (user.walletBalance < amount) return { ok: false, message: 'Insufficient balance to disburse this transfer' };

    updateUser({ ...user, walletBalance: user.walletBalance - amount });
    return { ok: true, message: `₦${amount.toLocaleString()} disbursed to ${beneficiaryAccount} (${beneficiaryBank})` };
  };

  return (
    <WalletContext.Provider
      value={{ depositOpen, transferOpen, openDeposit, closeDeposit, openTransfer, closeTransfer, deposit, transfer }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
}