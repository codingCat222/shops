import axios from 'axios';

const API_URL = import.meta.env.PROD 
  ? 'https://shops-1-zq6e.onrender.com/api' 
  : 'http://localhost:5000/api';

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('shopfair_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('shopfair_token');
    }
    return Promise.reject(error);
  }
);